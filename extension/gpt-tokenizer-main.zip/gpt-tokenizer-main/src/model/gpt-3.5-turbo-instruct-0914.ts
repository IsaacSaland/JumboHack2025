// eslint-disable-next-line no-restricted-exports, import/no-default-export
export { default } from '../encoding/cl100k_base.js'
export * from '../encoding/cl100k_base.js'
