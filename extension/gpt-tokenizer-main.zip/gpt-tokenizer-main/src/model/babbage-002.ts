// eslint-disable-next-line no-restricted-exports, import/no-default-export
export { default } from '../encoding/p50k_base.js'
export * from '../encoding/p50k_base.js'
