// eslint-disable-next-line no-restricted-exports, import/no-default-export
export { default } from '../encoding/r50k_base.js'
export * from '../encoding/r50k_base.js'
