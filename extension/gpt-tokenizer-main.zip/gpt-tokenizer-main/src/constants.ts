export const ALL_SPECIAL_TOKENS = 'all'
export const DEFAULT_MERGE_CACHE_SIZE = 100_000
